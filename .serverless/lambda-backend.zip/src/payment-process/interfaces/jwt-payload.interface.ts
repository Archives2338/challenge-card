/* eslint-disable prettier/prettier */
export interface JwtPayload {
 token:string;

}
